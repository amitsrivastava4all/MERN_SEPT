import { ajax } from "./ajax.js";

window.addEventListener('load', bindEvents);
function bindEvents(){
    document.getElementById('searchbt')
    .addEventListener('click', searchIt);
}

function searchIt(){
    const singerName = document.getElementById('searchbox')
    .value;
    ajax(singerName, printSongs);

}

function songCard(song){
    /*
    <div class="card" style="width: 18rem;">
  <img src="..." class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div> */
    const cardDiv = document.createElement('div'); //<div> </div>
    cardDiv.className = 'card';
    cardDiv.style.width = '18rem';
    const image = document.createElement('img');
    image.src = song['artworkUrl100'];
    cardDiv.appendChild(image); 
    document.getElementById('songs').appendChild(cardDiv);
    // Audio Player 
}

function printSongs(json){
    //console.log('Print Songs JSON Rec ', json);
    document.getElementById('songs').innerHTML = '';
    const obj = JSON.parse(json);
    console.log('Object Rec ', obj);
    const songs = obj['results'];
    songs.forEach(song =>songCard(song));
}