import logo from './logo.svg';
import './App.css';
import { Dashboard } from './modules/dashboard/pages/Dashboard';

function App() {
  return (
    <Dashboard/>
  );
}

export default App;
