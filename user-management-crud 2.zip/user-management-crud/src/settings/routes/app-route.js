import Switch, { Route } from 'react-router-dom';
import { ViewAll } from '../../modules/user/view-all/components/ViewAll';
import { AddUser } from '../../modules/user/add/components/AddUser';
export const RouteConfig = ()=>{
    return (
        <Switch>
            <Route path="/" element= {<ViewAll/>}></Route>
            <Route path ="/add-user" element={<AddUser/>}></Route>
            <Route path = "/delete-user" element={<ViewAll/>}></Route>
        </Switch>
    )
}