import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import TableViewIcon from '@mui/icons-material/TableView';
import AddBoxIcon from '@mui/icons-material/AddBox';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import { useState } from 'react';
export const NavBar = ()=>{
    const [value, setValue] =useState(0);

    const tabChange = (event, newValue) => {
        console.log('Tab Change Call...', newValue);
     setValue(newValue);
    };
    return (
        <Tabs variant="fullWidth" value={value} onChange={tabChange} aria-label="icon label tabs example">
      <Tab icon={<TableViewIcon />} label="View All" />
      <Tab icon={<AddBoxIcon />} label="Add New User" />
      <Tab icon={<DeleteForeverIcon />} label="Delete User" />
    </Tabs>
    );
}