
import Container from '@mui/material/Container';
import { NavBar } from '../components/NavBar';
export const Dashboard = ()=>{
    return (
        <Container maxWidth="lg">
            <NavBar/>
      </Container>
    );
}