export const ViewAll= ()=>{
    return <p>View All Records</p>
}