import { useSearchParams } from "react-router-dom"

export const AddUser  = ()=>{
    const [urlSearchParams] = useSearchParams(); // Query Param
    let value = '';
    for(let e of urlSearchParams.entries()){
        console.log(e[1]);
        value = value + e[1];
    }
    return (<p>Add New User {value}</p>)
}