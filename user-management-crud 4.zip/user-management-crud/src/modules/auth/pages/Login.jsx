import { useLocation } from "react-router-dom"

export const Login = ()=>{
    const params = useLocation();
    console.log(params);
    return (<p>Login Page... {params.state.message}</p>)
}