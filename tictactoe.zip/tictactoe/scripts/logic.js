// Game Logic
// when html is loaded then we want the bindEvent will be call
window.addEventListener('load', bindEvents);
// 1st Pick the Buttons
function bindEvents(){
const buttons = document.getElementsByTagName('button');

for(let i = 0 ;i<buttons.length; i++){
    buttons[i].addEventListener('click', printXOrZero);
}
}
// console.log(buttons.length);
// console.log(buttons[0].value);
let flag = true;
let clickCount = 0;
function printXOrZero(){
    // this is a keyword 
    // this - contains the current calling object reference
    // this - get the current button reference
    //console.log('Print X or Zero is called...', this);
    const currentButton = this;
    if(currentButton.innerText.length ==0){
    currentButton.innerText = flag?"X":"0"; 
    flag = !flag; 
    }
    // get the current clicked button
    // then print x or zero (if nothing is printed on button)
}

function isGameOver(){

}

function isThreeSame(){

}

function isNotBlank(){

}
function isDraw(){

}