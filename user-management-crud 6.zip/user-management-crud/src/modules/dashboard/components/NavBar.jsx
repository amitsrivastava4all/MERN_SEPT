import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import TableViewIcon from '@mui/icons-material/TableView';
import AddBoxIcon from '@mui/icons-material/AddBox';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import { useState } from 'react';
import { NavLink, Route } from 'react-router-dom';
import './NavBar.css';
import * as React from "react";
import { AppBar } from '@mui/material';
import { useNavigate, Link } from "react-router-dom";


const LinkTab=(props)=>{
  return (<Tab component = {Link} to = {props.pathname} {...props} />);
}
// Tab Click Index
const myProps = (index)=>{
  return {
    id:`nav-tab-${index}`, 'aria-controls':`nav-tab-panel-${index}`
  };
}

export const NavBar = ()=>{
    const [value, setValue] =useState(0);

    const tabChange = (event, newValue) => {
        console.log('Tab Change Call...', newValue);
     setValue(newValue);
    };
    return (
      <>
        
        {/* <NavLink to="/View" className={({isActive})=>isActive?"red":"green"} >View All</NavLink>
        &nbsp;
        <NavLink className={({isActive})=>isActive?"red":"green"} to="/add-user?save=local&message=Add" >Add User </NavLink>
        &nbsp;
        <NavLink style={({isActive})=>isActive?{color:'orange'}:{color:"green"}} to="/delete" >Delete User </NavLink>
        &nbsp;
        <NavLink style={({isActive})=>isActive?{color:'orange'}:{color:"green"}} to="/edit" >Edit User </NavLink>
      </> */}
     
        <Tabs variant="fullWidth" value={value} onChange={tabChange} aria-label="icon label tabs example">
       <LinkTab icon={<TableViewIcon />} label="View All" pathname="/View" {...myProps} />
       <LinkTab icon={<AddBoxIcon />} label="Add New User" pathname="/add-user" {...myProps} />
       <LinkTab icon={<DeleteForeverIcon />} label="Delete User" pathname="/delete" {...myProps} />
     </Tabs>
     </>
    );
}