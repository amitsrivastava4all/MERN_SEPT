import { useSelector } from "react-redux";
import { useParams } from "react-router-dom"

import {Table, TableContainer,TableBody, TableCell,TableHead,TableRow,Paper } from "@mui/material";

export const ViewAll= ()=>{
    let {mode} = useParams(); // Path Parameter
    // Connect Redux with React Component
    const users = useSelector(state=>state.users);
    console.log('User are ', users.users);
    return (
    <>
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
          <TableCell>
            Userid
          </TableCell>
          <TableCell>
            Password
          </TableCell>
          <TableCell>
            Email
          </TableCell>
          <TableCell>
            Phone
          </TableCell>
          <TableCell>
            Address
          </TableCell>
          </TableRow>
          </TableHead>
          <TableBody>
          {users.users.map(user=><TableRow>
            <TableCell>{user.userid}</TableCell>
            <TableCell>{user.password}</TableCell>
            <TableCell>{user.email}</TableCell>
            <TableCell>{user.phone}</TableCell>
            <TableCell>{user.address}</TableCell>
            </TableRow>
             )}
          </TableBody>
          </Table>
          </TableContainer>
    <p>View All Records Now Mode is {mode}</p>
    <p>Users are {users.users.length}</p>
   
    </>
    );
}