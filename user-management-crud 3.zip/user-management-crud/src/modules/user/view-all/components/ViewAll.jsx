import { useParams } from "react-router-dom"

export const ViewAll= ()=>{
    let {mode} = useParams(); // Path Parameter
    return <p>View All Records Now Mode is {mode}</p>
}