import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom"

import {Table, TableContainer,TableBody, TableCell,TableHead,TableRow,Paper } from "@mui/material";
import { useEffect } from "react";
import { getUsers } from "../../redux/user-slice";

export const ViewAllFromServer= ()=>{
    let {mode} = useParams(); // Path Parameter
    const dispatch = useDispatch();
    useEffect(()=>{
        console.log('UseEffect Call....');
        dispatch(getUsers());
    },[]);
    // Connect Redux with React Component
    const users = useSelector(state=>state.users.allusers);
    const isLoading = useSelector(state=>state.users.isLoading);
   
    console.log('#####****** User are ', users, 'Loading ... ', isLoading);
    return (
    <>
    {isLoading?<p>Loading...</p>:
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
          <TableCell>
            Userid
          </TableCell>
          <TableCell>
            Password
          </TableCell>
          <TableCell>
            Email
          </TableCell>
          <TableCell>
            Phone
          </TableCell>
          <TableCell>
            Address
          </TableCell>
          </TableRow>
          </TableHead>
          <TableBody>
          {users.map(user=><TableRow>
            <TableCell>{user.username}</TableCell>
            <TableCell>{user.password}</TableCell>
            <TableCell>{user.email}</TableCell>
            <TableCell>{user.phone}</TableCell>
            <TableCell>{user.address.city}</TableCell>
            </TableRow>
             )}
          </TableBody>
          </Table>
          </TableContainer>
}
   
   
    </>
    );
}