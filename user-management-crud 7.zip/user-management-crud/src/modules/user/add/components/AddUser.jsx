import { useDispatch } from "react-redux";
import { useSearchParams } from "react-router-dom"
import { add } from "../../redux/user-slice";
import TextField from '@mui/material/TextField';
import { useEffect, useRef } from "react";

export const AddUser  = ()=>{
    const [urlSearchParams] = useSearchParams(); // Query Param
    let value = '';
    const userid = useRef('');
    const password = useRef('');
    const email = useRef('');
    const phone = useRef('');
    const address = useRef('');
    const dispatch = useDispatch(); // React Redux Predefine Hook
    useEffect(()=>{
        userid.current.focus();
    },[]);
    const addNewUser = ()=>{
        const useridValue = userid.current.value;
        const passwordValue = password.current.value;
        const emailValue = email.current.value;
        const phoneValue = phone.current.value;
        const addressValue = address.current.value;
        console.log(useridValue, passwordValue, emailValue);
        dispatch(add({'userid':useridValue
        , 'password':passwordValue,'email':emailValue, 'phone':phoneValue,
         'address':addressValue }));
    }
    for(let e of urlSearchParams.entries()){
        console.log(e[1]);
        value = value + e[1];
    }
    // UserId, Password, Email , Phone, Address
    return (
    <>
    
    <p>Add New User {value}</p>
    {/* <input type='text' ref={userid} placeholder="Type Userid Here"/> */}
    { <TextField
          
          id="outlined-required"
          label="UserId"
          inputRef={userid}
          autoComplete="false"
          autoFocus  
          
        /> }
        <br/>
        <TextField
          id="outlined-password-input"
          label="Password"
          type="password"
          inputRef = {password}
        />
        <br/>
        <TextField
          
          id="outlined-required"
          label="Email"
          inputRef = {email}
          
        />
        <br/>
        <TextField
          
          id="outlined-required"
          label="Phone"
          inputRef = {phone}
        />
        <br/>
        <TextField
          
          id="outlined-required"
          label="Address"
          inputRef = {address}
          
        />
        <br/>
    <button onClick={addNewUser}>Add New User</button>
    </>)
}