import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { apiClient } from "../../../shared/services/api-client";

// API Calls (async)
export const getUsers = createAsyncThunk("/get-users",async ()=>{
    console.log('Thunk Call....');
    const URL = process.env.REACT_APP_USERS_URL;
    const users = await apiClient.get(URL);
    console.log('******* Thunk Users ', users.data);
    return users.data; // fill in action.payload

})
const userSlice = createSlice({
    name:'users',
    initialState :{'users':[],isLoading:true, 'allusers':[]},
    reducers:{
            // CRUD Sync Operations
            // action contains data from UI inside the key called payload
            add(state, action){
                console.log("I am in Add ", state, 'Action ... ', action);
                state.users.push(action.payload)
                console.log('After Add in State ', state);
            },
            update(){

            }
    },
    extraReducers:{
        [getUsers.pending]:(state, action)=>{
            state.isLoading=true;
        },
        [getUsers.fulfilled]:(state, action)=>{
            state.isLoading = false;
            console.log('Data FulFilled ', action.payload);
            state.allusers = action.payload;
            console.log('State All Users ', state.allusers);
        },
        [getUsers.rejected]:(state, action)=>{
            state.isLoading = false;
            state.error = action.payload;
        }
    }
});
export  const {add, update} = userSlice.actions;
export default userSlice.reducer;