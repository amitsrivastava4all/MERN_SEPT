import { configureStore } from "@reduxjs/toolkit";
import userReducer from '../modules/user/redux/user-slice'
export default configureStore({
    reducer:{
        users: userReducer,
        //dashboard: dashBoardReducer
    }
})