import { Route, Routes } from "react-router-dom"
import { ViewAll } from "../../modules/user/view-all/components/ViewAll"
import { AddUser } from "../../modules/user/add/components/AddUser"
import { FileNotFound } from "../../shared/components/FileNotFound"
import { Login } from "../../modules/auth/pages/Login"

export const AppRoutes = ()=>{
    return (<Routes>
        <Route path = "/:mode" element = {<ViewAll/>}/>
        <Route path = "/add-user" element = {<AddUser/>}/>
        <Route path = "/logout" element = {<Login/>} />
        <Route path = "*" element = {<FileNotFound/>}/>
    </Routes>)
}