
import Container from '@mui/material/Container';
import { NavBar } from '../components/NavBar';
import { AppRoutes } from '../../../settings/routes/app-routes';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
export const Dashboard = ()=>{
    const navigate = useNavigate();
    const doLogout = ()=>{
        navigate("/logout",{
            state:{message:'U Logout SuccessFully...'}
        });
    }
    return (
        <Container maxWidth="lg">
            <NavBar/>
            <br/>
            <Button onClick={doLogout} variant="contained">Logout</Button>
            <AppRoutes/>
            
      </Container>
    );
}