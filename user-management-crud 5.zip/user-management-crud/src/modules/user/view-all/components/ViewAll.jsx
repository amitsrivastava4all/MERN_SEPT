import { useSelector } from "react-redux";
import { useParams } from "react-router-dom"

export const ViewAll= ()=>{
    let {mode} = useParams(); // Path Parameter
    // Connect Redux with React Component
    const users = useSelector(state=>state.users);
    console.log('User are ', users.users);
    return (
    <>
    <p>View All Records Now Mode is {mode}</p>
    <p>Users are {users.users.length}</p>
    </>
    );
}