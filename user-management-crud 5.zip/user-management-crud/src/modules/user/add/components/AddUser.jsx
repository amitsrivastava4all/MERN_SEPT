import { useDispatch } from "react-redux";
import { useSearchParams } from "react-router-dom"
import { add } from "../../redux/user-slice";

export const AddUser  = ()=>{
    const [urlSearchParams] = useSearchParams(); // Query Param
    let value = '';
    const dispatch = useDispatch(); // React Redux Predefine Hook
    const addNewUser = ()=>{
        dispatch(add({id:1001, name:'Amit'}));
    }
    for(let e of urlSearchParams.entries()){
        console.log(e[1]);
        value = value + e[1];
    }
    return (
    <>
    <p>Add New User {value}</p>
    <button onClick={addNewUser}>Add New User</button>
    </>)
}