import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
    name:'users',
    initialState :{'users':[]},
    reducers:{
            // CRUD Sync Operations
            // action contains data from UI inside the key called payload
            add(state, action){
                console.log("I am in Add ", state, 'Action ... ', action);
                state.users.push(action.payload)
                console.log('After Add in State ', state);
            },
            update(){

            }
    }
});
export  const {add, update} = userSlice.actions;
export default userSlice.reducer;