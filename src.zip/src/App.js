import logo from './logo.svg';
import './App.css';
import { LifeCycle } from './components/LifeCycle';

function App() {
  return (
   <LifeCycle a="9990"/>
  );
}

export default App;
