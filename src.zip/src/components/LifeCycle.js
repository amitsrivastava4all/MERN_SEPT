import {Component, PureComponent} from 'react';
export class LifeCycle extends PureComponent{
    constructor(props){
        super(props);// Parent Class Constructor
        this.state = {counter:1000};
        console.log('1. Cons Call This is ',this);
        // Bind Event 
        this.doPlus = this.doPlus.bind(this);
        
    }
    // Dep From React 17 Onwards
    // UNSAFE_componentWillMount(){
    //     console.log('UNSAFE_componentWillMount ')
    // }
    // react 17 onwards (rare to use)
    // use to sync state and props whenever required
    /*static getDerivedStateFromProps(props, state){
       console.log('2. getDerivedStateFromProps (Mounting and Updation)');
        return {
            oldcount : state.counter,
            counter: state.counter + 1000 + parseInt(props.a),
            newVal: props.a
        }
    }*/
    /*shouldComponentUpdate(nextProps, nextState){
        if(this.state.counter + 10 === nextState.counter){
            return false
        }
        if(nextProps.a === nextState.counter){
            return false;
        }
        return true;  
    }*/
    doPlus(){
        console.log('Do Plus Call ', this);
        this.setState({...this.state, counter: this.state.counter + 1});
    }
    render(){
        console.log("3. Render Call ");
        return (<div>
            <h1>Life Cycle Methods {this.state.counter} and {this.state.newVal}</h1>
            <button onClick={this.doPlus}>Plus It </button>
        </div>)
    }
    // After Render call and component is mounted on DOM
    componentDidMount(){
        console.log('4. After Render componentDidMount ');
        // Dom Avaliable
        const img = document.createElement('img');
        img.src = 'https://w7.pngwing.com/pngs/403/269/png-transparent-react-react-native-logos-brands-in-colors-icon-thumbnail.png';
        document.body.appendChild(img);
        // event binding
        img.addEventListener('click',()=>{
            alert("U click on this image");
        })
        // Network calls
        this.getNews();
        this.animation();
    }
    getNews(){
        // Network calls
    }
    animation(){
        // Animation 
    }
}