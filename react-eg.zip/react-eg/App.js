// Root Component
// function App(){
//   return (<h1>Hello React JS.....</h1>); // JSX
// }
import React, { useState } from 'react';
import './App.css';
const App = ({name, price, location})=>{
  // All hooks start with use
  const [countValue, setCount ]  = useState(0); // State Value is 0 , We do DeStrucuture (Array)
  //console.log('Props is ', typeof props, 'Props Value ', props);
  const message = 'React JS...';
  //let countValue = 0; // Data 
  const plus = ()=>{
   // countValue++;
   setCount(countValue + 1);
    console.log('Count Value is ',countValue);
  }
  //const name= 'Amit';
  const myStyle = {
    backgroundColor : 'yellow',
    color : 'blue'
  }
  // const h1Tag=  React.createElement('h1',{
  //   className :'mycolor'
  // },'Hello React JS');
  // const h2Tag=  React.createElement('h2',
  // {style: myStyle}
  // ,'Hi React JS');
  // const divTag = React.createElement('div',null, h1Tag, h2Tag);
  // return divTag;
  // return React.createElement('div', null, 
  // React.createElement('h1', {className:'mycolor'},message)
  // , React.createElement('h2', {style: myStyle},name))
  const flag = true;
  //const fruits = ['Apple', 'Orange', 'Mango']; // Data
  const fruits = [{id:1001, name:'Apple' , price:99}, {id:1002, name:'Mango', price:120} , {id:1003, name:'Orange', price:77}];
  // Conditional Rendering
  const jsx = flag ? <h1>Hello {message}</h1>  : <h2 className = "mycolor">Hi {message}</h2>;
return (<div>
    {jsx}
    {/* <p>Props Rec {props.name} {props.price} {props.location.city} {props.location.country}</p>
    <p className = 'mycolor'>Hi React </p> */}
    <p>Props DeStrucutre {name} {price} {location.country} {location.city}</p>
    <input type='text' placeholder='Type Name here'/>
    <br/>
    <br/>
    <button onClick={plus}>Click Me</button>
    <p>Count is {countValue}</p>
    <p>Iterative rendering</p>
    <ul>

      {fruits.map((fruit)=><li key={fruit.id}>{fruit.name} {fruit.price}</li>)}
    </ul>
  
  <p style = {myStyle}>My Name is {name}</p>
  </div>)
 }
export default App;