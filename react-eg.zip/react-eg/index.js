// index.js is a file which connect Root component (App Component)
// with index.html (Page)
import App from './App';
import ReactDOM from 'react-dom/client';
const div = document.querySelector('#root');
const root = ReactDOM.createRoot(div);
const myObject = {city:'Delhi', country:'India'};
root.render(<App name='Apple'  price = '99' location = {myObject}/>);
// Component will be call in JSX Style.
//ReactDOM.render(<App/>,div);